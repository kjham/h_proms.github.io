---
layout: post
current: post
navigation: True
title: Bible Panorama 를 시작하며
date: 2018-02-19 00:00:00
tags: [religion-lab]
class: post-template
subclass: 'post tag-religion'
author: proms
---

저자 **"테리 홀"** 의 **"성경 파노라마"** !

이 책을 통해 기독교에 관하여 공부하고자 합니다.

'창세기' 부터 '요한계시록' 까지 한눈에 볼 수 있도록 쉽게 정리되어 있으며,
**구약시대, 신구약 중간, 신약 시대** 세 가지로 나누어 안내합니다.

![Bible Panorama]({{site.url}}/assets/images/religion_bible_panorama.jpg)

블로그 포스팅을 통해 유익한 내용은 공유하도록 하겠습니다.
물론, 저의 발전을 위한 포스팅이 우선이겠지만요 ^^